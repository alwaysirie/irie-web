// Helpers //

function isEven(value) {
	if (value%2 == 0)
		return true;
	else
		return false;
}

function addLocation(){
	var cnumber = document.getElementById('numberOfLocations').value;
	var number = parseInt(cnumber)+1
	if (isEven(number) == true){
		var color = 'eeeeee'
	}else{
		var color = 'ffffff'
	}
	var newLocation = '<div id="manageFormBox" style="background-color:#' + color + ';"><div class="manageFormHeading">Location #' + number + '</div><div class="manageFormTitle">Name:</div><div class="manageFormField"><input name="' + number + '[name]" id="' + number + '_name" /></div><div class="manageFormTitle">Address:</div><div class="manageFormField"><input name="' + number + '[address]" id="' + number + '_address" /></div><div class="manageFormTitle">City:</div><div class="manageFormField"><input name="' + number + '[city]" id="' + number + '_city" /></div><div class="manageFormTitle">State:</div><div class="manageFormField"><input name="' + number + '[state]" id="' + number + '_state" /></div><div class="manageFormTitle">Zipcode:</div><div class="manageFormField"><input name="' + number + '[zip]" id="' + number + '_zip" /></div><div class="manageFormTitle">Phone:</div><div class="manageFormField"><input name="' + number + '[phone]" id="' + number + '_phone" /></div></div>';
	document.getElementById('locations').innerHTML += newLocation;
	document.getElementById('numberOfLocations').value = number;
}

function addLocationEditCompany(){
	var enumber = document.getElementById('numberOfCurrentLocations').value;
	var cnumber = document.getElementById('numberOfLocations').value;
	var number = parseInt(cnumber)+1
	if (isEven(parseInt(enumber)+parseInt(number)) == true){
		var color = 'eeeeee'
	}else{
		var color = 'ffffff'
	}
	var newLocation = '<div id="manageFormBox" style="background-color:#' + color + ';"><div class="manageFormHeading">New Location #' + number + '</div><div class="manageFormTitle">Name:</div><div class="manageFormField"><input name="' + number + '[name]" id="' + number + '_name" /></div><div class="manageFormTitle">Address:</div><div class="manageFormField"><input name="' + number + '[address]" id="' + number + '_address" /></div><div class="manageFormTitle">City:</div><div class="manageFormField"><input name="' + number + '[city]" id="' + number + '_city" /></div><div class="manageFormTitle">State:</div><div class="manageFormField"><input name="' + number + '[state]" id="' + number + '_state" /></div><div class="manageFormTitle">Zipcode:</div><div class="manageFormField"><input name="' + number + '[zip]" id="' + number + '_zip" /></div><div class="manageFormTitle">Phone:</div><div class="manageFormField"><input name="' + number + '[phone]" id="' + number + '_phone" /></div></div>';
	document.getElementById('locations').innerHTML += newLocation;
	document.getElementById('numberOfLocations').value = number;
}

function addDealSelectLocation(id){
	if (document.getElementById(id).className == 'locationDetails smallText'){
		document.getElementById(id).className = 'locationDetails smallText on';
		document.getElementById('selectedlocations').value += id + ',';
	}else{
		document.getElementById(id).className = 'locationDetails smallText';
		var currentVal = document.getElementById('selectedlocations').value;
		var id = id + ',';
		document.getElementById('selectedlocations').value = currentVal.toString().replace(id, "");
	}
}