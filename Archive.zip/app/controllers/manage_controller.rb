class ManageController < ApplicationController
  
  #
  # Companies
  #
  
  def all_companies
    @companies = Company.all()
  end
  
  def add_company
    if params[:company] != nil
      company = Company.new(params[:company])
      numberOfLocations = 0
      params[:numberOfLocations].to_i.times do
        numberOfLocations+=1
        location = StoreLocation.new(params["#{numberOfLocations.to_s.to_sym}"])
        company.store_locations << location
      end
      company.save
      redirect_to(:action => 'all_companies')
    end
  end
  
  def company
    @company = Company.find(params[:id])
  end
  
  def edit_company
    @company = Company.find(params[:id])
    if params[:company] != nil
      @company.update_attributes(params[:company])
      for l in @company.store_locations
        l.update_attributes(params["#{l.id.to_s.to_sym}"])
      end
      numberOfLocations = 0
      params[:numberOfLocations].to_i.times do
        numberOfLocations+=1
        location = StoreLocation.new(params["#{numberOfLocations.to_s.to_sym}"])
        @company.store_locations << location
      end
      @company.save
      redirect_to(:action => 'company', :id => @company.id)
    end
  end
  
  #
  # Deals
  #
  
  def add_deal
    @company = Company.find(params[:id])
    if params[:deal] != nil
      deal = Deal.new(params[:deal])
      deal.start_date = ("#{params[:start]['date(1i)']}-#{params[:start]['date(2i)']}-#{params[:start]['date(3i)']}").to_time
      deal.end_date = ("#{params[:end]['date(1i)']}-#{params[:end]['date(2i)']}-#{params[:end]['date(3i)']}").to_time
      deal.company_id = @company.id
      locations = []
      locs = params[:selectedlocations].split(',')
      for l in locs
        locations.push(l)
      end
      deal.locations = locations
      deal.save
      @company.recount_deals
      redirect_to(:action => 'company', :id => @company.id)
    end
  end
  
  def edit_deal
    @deal = Deal.find(params[:id])
    @company = Company.find(@deal.company_id)
    if params[:deal] != nil
      @deal.start_date = ("#{params[:start]['date(1i)']}-#{params[:start]['date(2i)']}-#{params[:start]['date(3i)']}").to_time
      @deal.end_date = ("#{params[:end]['date(1i)']}-#{params[:end]['date(2i)']}-#{params[:end]['date(3i)']}").to_time
      @deal.locations.clear
      @deal.save
      locs = params[:selectedlocations].split(',')
      for l in locs
        @deal.locations << l
      end
      @deal.update_attributes(params[:deal])
      if params[:upload] != nil
        if params[:upload][:home] != nil
          @deal.upload_photos('home', params[:upload])
        end
        if params[:upload][:weekly] != nil
          @deal.upload_photos('weekly', params[:upload])
        end
        if params[:upload][:hero] != nil
          @deal.upload_photos('hero', params[:upload])
        end
      end
      @company.recount_deals
      #redirect_to(:action => 'deal', :id => @deal.id)
    end
  end
  
  def deal
    @deal = Deal.find(params[:id])
    @company = Company.find(@deal.company_id)
  end
  
  #
  # test
  #
  
  def delete_deals
    for d in Deal.all
      d.destroy
    end
  end
  
end
