class AdminController < ApplicationController
  
  def method_name
    
  end

end