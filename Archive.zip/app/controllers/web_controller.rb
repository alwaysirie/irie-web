class WebController < ApplicationController
  
  before_filter :check_aff
  
  def index
    @deals = Deal.all()
    @weekly = Deal.all(:limit => 3, :status => 'featured')
  end
  
  def deal
    @deal = Deal.find(params[:id])
    @locations = Company.find(@deal.company_id).store_locations
  end
  
  #
  # Login
  #
  
  def login
    if params[:user] != nil
      session[:user] = tryToLogin(params[:user][:email], params[:user][:password])
      return redirect_to(:action => 'index')
    end
    if params[:customer] != nil
      customer = Customer.create!(params[:customer])
      session[:user] = {'user_id' => customer.id, 'full_name' => customer.full_name}
      return redirect_to(:action => 'index')
    end
  end
  
  #
  # Checkout
  # 
  
  def purchaseDeal
    @deal = Deal.find(params[:id])
    if session[:user] != nil
      @user = Customer.find(session[:user]['user_id'])
    end
  end
  
  def checkoutLogin
    if params[:user] != nil
      session[:user] = tryToLogin(params[:user][:email], params[:user][:password])
    end
    redirect_to(:action => 'purchaseDeal', :id => params[:id])
  end
  
  def confirmPurchase
    deal = Deal.find(params[:id])
    if session[:user] == nil
      customer = Customer.new(params[:customer])
      customer.address = params[:card][:address]
      customer.city = params[:card][:city]
      customer.state = params[:card][:state]
      customer.zip = params[:card][:zip]
      customer.save
      session[:user] = {'user_id' => customer.id, 'full_name' => customer.full_name}
    else
      customer = Customer.find(session[:user]['user_id'])
    end
    voucher = Voucher.createVoucher(deal.id, customer.id)
    if voucher == 'purchased'
      flash[:error] = "I'm sorry, you have already purchased this deal."
      return redirect_to(:action => 'purchaseDeal', :id => deal.id)
    end
    if params[:ccgroup] != nil
      card = CreditCard.find(params[:ccgroup])
    else
      card_info = {'number' => params[:card][:number], 'month' => params[:card][:month], 'year' => params[:card][:year], 'cvv' => params[:card][:cvv], 'name' => params[:card][:name], 'address' => params[:card][:address], 'city' => params[:card][:city], 'state' => params[:card][:state], 'zip' => params[:card][:zip] }
      card = CreditCard.create_card(card_info, customer.id)
    end
    if card == nil
      flash[:error] = "There is a problem with your credit card. Please check it and try again."
      return redirect_to(:action => 'purchaseDeal', :id => params[:id])
    end
    if card.chargeCreditCard == 'fail'
       flash[:error] = "I'm sorry, It seems your credit card has declined."
       return redirect_to(:action => 'purchaseDeal', :id => deal.id)
     else
      voucher.markPurchased
      if session[:aff] != nil
        customer.addAffiliateDeal(session[:aff], voucher.id)
      end
      redirect_to(:action => 'myAccount')
    end
  end
  
  def logout
    session[:user] = nil
    redirect_to('/')
  end
  
  #
  # Client Area
  #
  
  def myAccount
    checkStatus(session[:user])
  end
  
  def purchasedDeal
    @voucher = Voucher.find(params[:id])
    @deal = Deal.find(@voucher.deal_id)
    render :layout => false
  end
  
  #
  #
   private
  #
  #
  
  def tryToLogin(username, password)
    logged_in_user = Customer.authenticate(username, password)
    if logged_in_user != nil
      return {'user_id' => logged_in_user.id, 'full_name' => logged_in_user.full_name}
    else
      return nil
    end
  end
  
  def checkStatus(user)
    if user == nil
      redirect_to(:action => 'index')
    else
      @user = Customer.find(user['user_id'])
    end
  end
  
  def check_aff
    if params[:aff] != nil
      session[:aff] = params[:aff]
    end
  end
  
end
