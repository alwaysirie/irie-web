class Deal
	include MongoMapper::Document
	before_save :totaldiscount
	before_create :change_structure

	key :company_id, ObjectId
	key :name, String

	key :cost, Money
	key :retail, Money
	key :purchases, Integer
	key :discount, Money

	key :start_date, Time
	key :end_date, Time
	
	key :user_exp_date, Time

	key :headline, String
	key :summary, String

	key :description, String
	key :fine_print, String
	
	key :status, Lowercase

  key :locations, Array
  
  #photos
  key :home, String
  key :weekly, String
  key :hero, String
  
	belongs_to :company
	many :vouchers
	
	# Before Filters
	
	def change_structure
	  self.id="#{self.company_id}D#{Deal.count(:company_id => self.company_id).to_i + 1}"
	  self.purchases = 0
	end
	
	def totaldiscount
	  self.discount = (self.cost/self.retail)*100.to_i
  end
  
  def timeRemaining
    ((self.end_date - Time.now)/86400).to_i
  end

  # Photos
  
  def upload_photos(photoType, upload)
     name = "#{self.id}_#{photoType}_#{upload["#{photoType}"].original_filename}"
     directory = "public/images/"
     # create the file path
     path = File.join(directory, name)
     # write the file
     File.open(path, "wb") { |f| f.write(upload["#{photoType}"].read) }
     eval("self.#{photoType} = '#{name}'")
     self.save
  end
  
end