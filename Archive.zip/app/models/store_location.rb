include GeoKit::Geocoders
class StoreLocation
  include MongoMapper::EmbeddedDocument
  before_save :geofy
  
  key :name, String
  key :address, String
  key :city, String
  key :state, String
  key :zip, String
  key :phone, String
  key :lat, String
  key :lng, String
  
  # Helper
  
  def full_address
    "#{self.address}<br>#{self.city}, #{self.state} #{self.zip}"
  end
  
  def geofy
    require 'geokit'

    coords = MultiGeocoder.geocode("#{self.address}, #{self.city}, #{self.state} #{self.zip}")
    self.lat = coords.lat
    self.lng = coords.lng
  end
  
end
