require 'digest/sha2'
class Voucher
	include MongoMapper::Document
	before_create :change_id
	
	def change_id
	 self.id = "#{self.deal.company_id.upcase}D#{Time.now.strftime('%j%H%I%M%S')}#{SecureRandom.base64(6).to_s.gsub(/[^0-9A-Za-z]/, '').upcase}"
	end

	key :customer_id, ObjectId
	key :deal_id, ObjectId

	key :start_date, Time
	key :exp_date, Time
	key :purchase_date, Time

	key :status, String

	key :used_date, String
	
	belongs_to :customer
	belongs_to :deal

	# Actions
	
	def self.createVoucher(deal_id, customer_id)
	 existing = Voucher.first(:customer_id => customer_id, :deal_id => deal_id, :status => 'pending')
	 if existing != nil
	   return existing
   end
    purchased = Voucher.first(:customer_id => customer_id, :deal_id => deal_id, :status.ne => 'pending')
 	 if purchased != nil
 	   return 'purchased'
    end
   deal = Deal.find(deal_id)
	 voucher = Voucher.new()
	 voucher.deal_id = deal_id
	 voucher.customer_id = customer_id
	 voucher.start_date = Time.now
	 voucher.exp_date = deal.user_exp_date
	 voucher.status = 'pending'
	 voucher.save
	 return voucher
	end
	
	def markPurchased
	  self.status = 'active'
	  self.purchase_date = Time.now
	  deal = Deal.find(self.deal_id)
	  deal.increment(:purchases => 1)
	  Customer.find(self.customer_id).increment(:deals_purchased => 1, :money_saved => (deal.retail-deal.cost))
	  self.save
  end

end
