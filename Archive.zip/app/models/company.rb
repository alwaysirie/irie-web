class Company 
	include MongoMapper::Document
	
	before_create :change_structure

	key :name, String
	key :phone, Phone
	key :url, String
	
	key :active_deals, Integer, :default => 0
	key :pending_deals, Integer, :default => 0
	key :expired_deals, Integer, :default => 0
	
	many :store_locations
	many :deals
	
	# Before Functions
	
	def change_structure
	 self.id = "#{Company.all.count.to_i + 1}C"
	 self.url = self.url.gsub('http://', '').gsub('https://', '').to_s
	end
	
	# Actions
	
	def recount_deals
	  self.active_deals = Deal.count(:company_id => self.id, :status => 'active')
	  self.active_deals = Deal.count(:company_id => self.id, :status => 'pending')
	  self.active_deals = Deal.count(:company_id => self.id, :status => 'expired')
	  self.save
	end
	
	# Helpers
	
	def deal_count
	  (self.active_deals + self.pending_deals + self.expired_deals).to_i
	end
	
	

end
