require 'digest/sha2'
class Customer
	include MongoMapper::Document
	before_create :change_id
  
  def change_id
    self.id = (Customer.all().count+1).to_s
  end

	# Password Area
  attr_accessor :new_password, :new_password_confirmation
  validates_confirmation_of :new_password, :if => :password_changed?
  before_save :hash_new_password, :if => :password_changed?
      
  def password_changed?
     !@new_password.blank?
  end

  key :first_name, Lowercase
  key :last_name, Lowercase
  key :email, Lowercase
  key :phone, Phone
  key :address, String
  key :city, Lowercase
  key :state, Lowercase
  key :zip, Lowercase
  key :country, Lowercase


	# Login
  key :salt, String
  key :hashed_password, String
  key :reset_key, String
  key :new_password2, String
  
  # Credit Card Information
  key :encryptedcc, String
  
  # Stats
  key :deals_purchased, Integer, :default => 0
  key :money_saved, Money, :default => 0

  # Associations
  many :vouchers
  many :points
  many :credit_cards
  many :affiliate_deals
  
  # Helpers
  
  def full_name
    "#{self.first_name.titleize} #{self.last_name.titleize}"
  end
  
  # Affiliates
  
  def addAffiliateDeal(id, voucher_id)
    customer = Customer.find(id)
    voucher = Voucher.find(voucher_id)
    deal = Deal.find(voucher.deal_id)
    affiliate_deal = AffiliateDeal.find(:deal_id => deal.id, :customer_id => customer.id)
    if affiliate_deal == nil
      affiliate_deal = AffiliateDeal.new(:customer_id => customer.id, :deal_id => deal.id, :deals_sold => 0)
    end
    affvoucher = AffiliateVoucher.new()
    affvoucher.amount = deal.cost
    affvoucher.earned = (deal.cost*0.50)
    affvoucher.voucher_id = voucher.id
    affvoucher.customer_id = voucher.customer_id
    affiliate_deal.affiliate_vouchers << affvoucher
    affiliate_deal.save
  end

  # Password area
  
  def self.authenticate(username, password)
    if user = Customer.where(:email => username.downcase).first
      if user.hashed_password == Digest::SHA2.hexdigest(user.salt + password)
        return user
      end
    end
    return nil
  end
  
  def reset_password(link)
    self.reset_key = SecureRandom.base64(6).to_s.gsub(/[^0-9A-Za-z]/, '')
    UserMailer.reset_password(self.reset_key, self, link).deliver
    self.save
  end
  
  # Private
  private
  
  def hash_new_password
    self.salt = SecureRandom.base64(8)
    self.hashed_password = Digest::SHA2.hexdigest(self.salt + @new_password)
  end

end
