class Affiliate
  include MongoMapper::Document
  
  key :something, String
  
end
