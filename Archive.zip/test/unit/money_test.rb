require 'test_helper'

class MoneyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
