require 'test_helper'

class AffiliateVoucherTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
