require 'test_helper'

class AffiliateDealTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
