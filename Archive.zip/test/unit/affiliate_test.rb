require 'test_helper'

class AffiliateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
