require 'test_helper'

class StoreLocationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
