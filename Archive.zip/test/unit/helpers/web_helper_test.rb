require 'test_helper'

class WebHelperTest < ActionView::TestCase
end
