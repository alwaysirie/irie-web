require 'test_helper'

class ManageHelperTest < ActionView::TestCase
end
