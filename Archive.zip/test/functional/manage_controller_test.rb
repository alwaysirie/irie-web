require 'test_helper'

class ManageControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
