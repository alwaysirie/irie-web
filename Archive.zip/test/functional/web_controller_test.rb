require 'test_helper'

class WebControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
