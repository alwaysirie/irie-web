# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Nyt::Application.config.secret_token = '02d6f4308636c646d3bef7360091514326c8b64b7793be2cd5cfc99cb622835b6f19e0701c6d5cfe023c0dc6463ee7b2e13b80d5fee0064af99d22bfffc15886'
